// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCSHbAWVSqDvGM_c4jGR0ZqnIa8qe6MXSY",
  authDomain: "copsoq-respostas.firebaseapp.com",
  databaseURL: "https://copsoq-respostas-default-rtdb.firebaseio.com",
  projectId: "copsoq-respostas",
  storageBucket: "copsoq-respostas.firebasestorage.app",
  messagingSenderId: "596802278992",
  appId: "1:596802278992:web:32b943f09bebfc4303e355",
  measurementId: "G-4SJ7CKD2ZJ"
};
